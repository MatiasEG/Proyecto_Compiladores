///[Error:"hola|3]

"hola
chau"
