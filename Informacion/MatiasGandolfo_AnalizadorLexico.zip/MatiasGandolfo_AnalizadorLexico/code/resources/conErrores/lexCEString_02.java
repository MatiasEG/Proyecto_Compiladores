///[Error:" aca va el string sin cerrar|5]



" aca va el string sin cerrar