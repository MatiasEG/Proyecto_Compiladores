///[Error:'\u0|3]

'\u0R_ejemplo
