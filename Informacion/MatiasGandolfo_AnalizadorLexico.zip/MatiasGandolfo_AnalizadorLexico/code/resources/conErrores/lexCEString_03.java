///[Error:" este es un|3]

" este es un
        string con un enter"