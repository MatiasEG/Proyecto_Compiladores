///[Error:/* Hello world /|3]

/* Hello world /