///[Error:_|8]

// Un identificador no puede arrancar con '_' solo puede contenerlos al medio o al final

asd_
        as_d

        _asd