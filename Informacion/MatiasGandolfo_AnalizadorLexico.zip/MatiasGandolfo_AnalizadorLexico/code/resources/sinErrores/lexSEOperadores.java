a + b - c = "pez"

PC * agua != buenaOnda

+.*||