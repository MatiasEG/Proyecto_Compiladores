'\u0000'

'\u0123'

'\uFFFF'

" '\uFa3c' "

        '\uFa3c'