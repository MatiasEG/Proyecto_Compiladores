public class HolaMundo{
    System.out.println("Hola mundo");
}