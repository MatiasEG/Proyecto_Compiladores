""

"                     "

"hola"

"#%$%@#@#$!$!%&%&*^("

"class"

"Token"

        "\""

                    " asd \" asd   '\n' "

"EOF"